/**
 * Spring Data JPA repositories.
 */
package com.isw.app.repository;
