/**
 * View Models used by Spring MVC REST controllers.
 */
package com.isw.app.web.rest.vm;
