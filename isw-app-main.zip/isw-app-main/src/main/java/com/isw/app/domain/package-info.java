/**
 * JPA domain objects.
 */
package com.isw.app.domain;
